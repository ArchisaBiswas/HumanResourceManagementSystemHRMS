function ep_redirect()
{
    window.location.href = "../Employee_Portal/template/employee_portal_index.php";
}

function is_redirect()
{
    window.location.href = "../Interview_Scheduling/interview_scheduling.html";
}

function b_redirect()
{
    window.location.href = "../Benched/benched.html";
}